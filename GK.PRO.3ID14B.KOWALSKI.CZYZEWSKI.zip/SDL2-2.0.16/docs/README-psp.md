PSP
======
SDL port for the Sony PSP contributed by 
   Captian Lex 

Credit to
   Marcus R.Brown,Jim Paris,Matthew H for the original SDL 1.2 for PSP
   Geecko for his PSP GU lib "Glib2d"

Building
--------
To build for the PSP, make sure psp-config is in the path and run:
   make -f Makefile.psp



To Do
------
PSP Screen Keyboard
