var searchData=
[
  ['nframes_0',['nframes',['../struct_sprite.html#a195fd121e81102c43646fe0b07a51f7c',1,'Sprite']]],
  ['numbers_1',['numbers',['../struct_f_p_s___counter.html#a4c3257d330d51080c25c42154a37f8b4',1,'FPS_Counter']]]
];
