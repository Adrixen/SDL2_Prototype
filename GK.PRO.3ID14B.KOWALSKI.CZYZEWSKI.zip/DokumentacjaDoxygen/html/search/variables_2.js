var searchData=
[
  ['fps_5fcur_0',['fps_cur',['../struct_f_p_s___counter.html#a7ca64ce72a864b996ba6a88140222958',1,'FPS_Counter']]],
  ['fps_5fprev_1',['fps_prev',['../struct_f_p_s___counter.html#a7833ea77732a8890a891cf5fbaa4cab5',1,'FPS_Counter']]]
];
