var searchData=
[
  ['player_0',['Player',['../struct_player.html',1,'']]]
];
