var searchData=
[
  ['h_0',['h',['../struct_map.html#ae0643a7a998c28ea074381ae8a802854',1,'Map']]],
  ['height_1',['height',['../struct_sprite.html#a1f07c8f2080c193759aec0e13503d7ab',1,'Sprite']]]
];
