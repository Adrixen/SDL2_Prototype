var searchData=
[
  ['backwards_0',['backwards',['../struct_player.html#a89c570780d22ee777b215187676f2233',1,'Player']]]
];
