var searchData=
[
  ['sprite_5fw_0',['sprite_w',['../struct_player.html#ad5c070f3ecead8c2226a87dba2f6c413',1,'Player']]],
  ['sprites_1',['sprites',['../struct_player.html#a28875f7b0a2159bcfced1130452244c0',1,'Player']]],
  ['state_2',['state',['../struct_player.html#a2e6eb92136b8d3a47547f53831591f3e',1,'Player']]]
];
