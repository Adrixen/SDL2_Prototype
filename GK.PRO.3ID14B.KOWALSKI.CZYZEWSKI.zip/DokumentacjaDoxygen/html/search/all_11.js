var searchData=
[
  ['y_0',['y',['../struct_player.html#a018c59d494fd12d80517b36d62621e34',1,'Player']]]
];
