var searchData=
[
  ['set_5fstate_0',['set_state',['../struct_player.html#a3ebd1c9b0d542aa486925e1a13eb691f',1,'Player']]],
  ['sprite_1',['Sprite',['../struct_sprite.html#a8b05d6c589baaf9f66d4f9acef34cdc3',1,'Sprite']]]
];
