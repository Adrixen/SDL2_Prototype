var searchData=
[
  ['jumpvy_0',['jumpvy',['../struct_player.html#acbef2b07bbaeaa463570cc946f648913',1,'Player']]]
];
