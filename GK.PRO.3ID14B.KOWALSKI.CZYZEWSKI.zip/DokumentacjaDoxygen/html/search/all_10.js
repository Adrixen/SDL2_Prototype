var searchData=
[
  ['w_0',['w',['../struct_map.html#a21e42d20381212b0bda7940f21f97312',1,'Map']]],
  ['width_1',['width',['../struct_sprite.html#a0a3364944c5e361fc9e7ae406224d682',1,'Sprite']]]
];
