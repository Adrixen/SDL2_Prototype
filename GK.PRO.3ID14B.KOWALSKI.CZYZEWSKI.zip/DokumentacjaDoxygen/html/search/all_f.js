var searchData=
[
  ['vy_0',['vy',['../struct_player.html#a97c9f469ef054e12fb85c6f239de3e12',1,'Player']]]
];
