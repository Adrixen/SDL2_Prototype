var searchData=
[
  ['level_0',['level',['../struct_map.html#a823c28d70d9fca7fd1b68600a8999d34',1,'Map']]],
  ['level2_1',['level2',['../struct_map.html#af7fe1b8b2180e9ab8f36cc4a8a3e8eeb',1,'Map']]]
];
