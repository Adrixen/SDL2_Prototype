var searchData=
[
  ['duration_0',['duration',['../struct_animation.html#ad9472aa3b7c58f3e88d31cc099631fb8',1,'Animation']]]
];
